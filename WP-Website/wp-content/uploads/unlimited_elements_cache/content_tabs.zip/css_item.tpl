{% if item.content_type == "id" and item.item_index > 1 %}
	{{ucfunc("put_hide_ids_css", item.element_id)}}
{% endif %}