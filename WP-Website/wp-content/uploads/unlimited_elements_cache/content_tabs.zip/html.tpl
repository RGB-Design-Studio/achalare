<div class="uc_bold_tabs padding {{remote_parent.class}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{uc_filtering_attributes|raw}} data-debug="{{debug_hidden_elements}}" data-editor="{{uc_inside_editor}}" {{remote_parent.attributes|raw}} data-collapsible="{{accordion_breakpoint}}" data-hash="{{set_url_hash}}" data-hash-scroll="{{scroll_to_head_after_hash_page_load}}" data-scroll-to-selected-tab-offset="{{scroll_to_head_after_tab_selected_offset}}" data-scroll-after-selected="{{scroll_to_tab_after_tab_select}}">
    	<ul class="tabs uc_tab_nav uc-items-wrapper">
        	{{put_items()}}
        </ul>
        <div class="panel-container uc-items-wrapper2">
			{{put_items2()}}
        </div>
  
  <div class="uc-accordion-contents-template" style="display:none">
    <div class="uc-accordion-icon">
      <span class="uc-accordion-icon-expand">{{accordion_expand_icon_html|raw}}</span>
      <span class="uc-accordion-icon-collapse">{{accordion_collapse_icon_html|raw}}</span>
    </div>
  </div>
  
</div>