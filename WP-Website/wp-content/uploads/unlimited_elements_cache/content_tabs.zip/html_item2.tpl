<div id="{{item.item_id}}" class="tab-container panes">
	<div>
      {% if item.content_type == "template" %}{{putElementorTemplate(item.template_templateid)}} {% endif %}
      {% if item.content_type == "content" %}
         <div class="ue-item-content-layout"> 
           <div class="ue-item-image-wrapper">{% if show_image == "true" %}<div class="ue-item-image"><img src="{{item.image}}" {{item.image_attributes|raw}}></div>{% endif %}</div>
           <div class="ue-item-content-wrapper">
           {% if show_title == "true" %}<div class="ue-content-title">{{item.title|raw}}</div>{% endif %}
           {% if show_text == "true" %}<div class="ue-content-text">{{item.tab_content|raw}}</div>{% endif %}
           {% if show_button == "true" %}<div class="ue-btn-wrapper"><a href="{{item.link|raw}}" class="uc_btn uc_more_btn" {{item.link_html_attributes|raw}}>{{button_text|raw}}</a></div>{% endif %}
           </div>  
         </div>
    {% endif %}
     
      {% if item.content_type == "id" %}
          <div class="ue-element" data-id="{{item.element_id|e('html_attr')}}"></div>
      {% endif %}
	</div>
</div>