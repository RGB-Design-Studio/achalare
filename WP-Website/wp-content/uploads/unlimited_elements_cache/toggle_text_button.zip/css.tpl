#{{uc_id}} .read_more{
  text-decoration:none;
  font-size:14px;
  color:white;
  transition:0.3s;
  cursor: pointer;
}