{{ ucfunc("put_docready_start") }}
		
  	jQuery("#{{uc_id}} .read_more").click(function(){
        jQuery("#{{uc_id}} .long_txt").toggle();
        jQuery("#{{uc_id}} .short_txt").toggle();
        jQuery("#{{uc_id}} .btn_txt_before_click").toggle();
        jQuery("#{{uc_id}} .btn_txt_after_click").toggle();
    });
    	
{{ ucfunc("put_docready_end") }}