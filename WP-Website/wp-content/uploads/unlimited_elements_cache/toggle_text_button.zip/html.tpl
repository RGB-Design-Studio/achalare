<div id="{{uc_id}}" class="toggle_text_button"> 
  
  <div class="short_txt">{{short_txt|raw}}</div>   
  <div class="long_txt" style="display:none;">{{long_txt|raw}}</div>  
  
  <div style="text-align:{{align_btn}};">  
    <span class="read_more">
      <span class="btn_txt_before_click">{{button_text|raw}}</span>
      <span class="btn_txt_after_click" style="display:none;">{{button_text_close|raw}}</span>
    </span>  
  </div>  
</div>