.uc_content_box_zoom_effect *{
	padding: 0;
}
#{{uc_id}} {
	background-color: #fff;
	transition: all 0.8s ease 0s;
    overflow:hidden;
    display:flex;
}
.uc_content_box_zoom_effect:hover {
	box-shadow: 0 -2px 29px 0 rgba(0,0,0,0.15);
}
.uc_content_box_zoom_effect:hover .uc_image {
	transform: scale(1.2);
	transition: all 0.8s ease 0s;
}

.uc_content_box_zoom_effect .uc_thumbnail {
	display: block;
	overflow: hidden;
	text-decoration: none;
    flex-shrink:0;
    flex-grow:0;
  
}
#{{uc_id}} .uc_image {
	width: 100%;
	transition: all 0.8s ease 0s;
    mix-blend-mode: {{blend_mode}};
    object-position: {{image_position}};
    display:block;
}
.uc_content_box_zoom_effect .uc_title {
	display: block;
	font-size: 24px;
	text-decoration: none;
}
.uc_content_box_zoom_effect .uc_content {
	line-height:1.5em;
    
}
#{{uc_id}} .uc_more {
	display: {{button_style}};
	color: {{button_color}};
	text-decoration: none;
    background-color:{{color}};
   
}

#{{uc_id}} .uc_more:hover {
    background-color:{{button_hover_color}};
    color:{{button_color_hover}};
}

#{{uc_id}} .uc_content_box_zoom_effect_image
{
object-fit:cover;
}