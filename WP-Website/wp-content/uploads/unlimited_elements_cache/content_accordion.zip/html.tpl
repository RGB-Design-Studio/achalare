<div class="uc_material_accordion {{remote_parent.class|raw}} {{uc_filtering_addclass}}"  id="{{uc_id}}" {{uc_filtering_attributes|raw}} data-name="{{accordion_name|e('html_attr')}}" data-scroll="{{scroll_to_head}}" data-offset="{{scroll_to_head_offset}}" data-closeothers="{{close_item_when_other_opens}}" data-set-hash="{{set_url_hash}}" {{remote_parent.attributes|raw}}>
  <div class="uc_container uc-items-wrapper">
    {{put_items()}}
  </div>
</div>