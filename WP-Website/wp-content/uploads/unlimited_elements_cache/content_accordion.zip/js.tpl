jQuery(document).ready(function(){
  function {{uc_id}}_start(){


    var objAccordion = jQuery("#{{uc_id}}");
    UCContentAccordion(objAccordion);

    var objRemoteOptions = {
      class_items:"uc_ac_box",
      class_active:"uc-item-active",
      selector_item_trigger:".uc_trigger"
    };

    {{ucfunc("put_remote_parent_js","objAccordion","objRemoteOptions")}}  

  }setTimeout(function(){if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
      jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});},100); 
});