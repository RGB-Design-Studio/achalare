{% set addclass = "" %}
{% set contentStyle = "" %}

{% if (first_appearance == "first_opened" and item.item_index==1) %}
	{% set add_class = "uc-item-active" %}
	{% set contentStyle = "style='display:block'" %}
{% elseif (first_appearance == "all_opened") %}

	{% set add_class = "uc-item-active" %}
	{% set contentStyle = "style='display:block'" %}
{% endif %}

{% set tabid = "ue-tab" ~ item.item_index %}
{% if item.tab_id is not empty %}
{% set tabid = item.tab_id %}
{% endif %}

<div id="#{{tabid}}" class="uc_ac_box {{item.item_repeater_class}} {{add_class}}" style="background-color:{{item_background_color}};">
  <a href="javascript:void(0)" class="uc-heading uc_trigger" role="button">
    <span class="uc_dactive bbb ue_accordion_icon">{{icon_html|raw}}</span> 
    <span class="uc_active bbb ue_accordion_icon">{{icon_active_html|raw}}</span>
    <{{heading_html_tag}} class="ue_heading_title">{{item.title|raw}}{% if (show_additional_header_content == "true") and (item.additional_heading_content is not empty) %}<span class="ue_ca_additional_content">{{item.additional_heading_content|raw}}</span>{% endif %}</{{heading_html_tag}}>
  </a>
  
  <div class="uc_content" {{contentStyle|raw}}>
    {% if item.content_type == "text" %}    
      
      {% if show_image == "true" %}
      {% if item.show_image != "hide" %}
      <div class="ue-item-image"><img src="{{item.image}}" {{item.image_attributes|raw}}></div>
      {% endif %}
      {% endif %}
   
      {% if show_image == "false" %}
      {% if item.show_image == "show" %}
      <div class="ue-item-image"><img src="{{item.image}}" {{item.image_attributes|raw}}></div>
      {% endif %}
      {% endif %}
    
      {% if show_title == "true" %}
      <{{title_html_tag}} class="ue-item-title">{{item.heading|raw}}</{{title_html_tag}}>
      {% endif %}

      {% if show_content == "true" %}
        <div class="ue-item-text">{{item.content|raw}}</div>
      {% endif %}

      {% if show_button == "true" %}    
    	 {% if item.button_text|raw is empty %}
              <a href="{{item.link|raw}}" class="uc_btn uc_more_btn" {{item.link_html_attributes|raw}}>{{button_text|raw}}</a>  
          {% else %} 
              <a href="{{item.link|raw}}" class="uc_btn uc_more_btn" {{item.link_html_attributes|raw}}>{{item.button_text|raw}}</a>
          {% endif %}
      {% endif %}
    {% endif %}
    
    {% if item.content_type == "template" %}
       {{putElementorTemplate(item.template_templateid)}}
    {% endif %}
  </div> 
</div>