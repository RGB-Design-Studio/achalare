#{{uc_id}} *{
  box-sizing: border-box;
}

#{{uc_id}} .uc_ac_box
{
  overflow:hidden;
}

#{{uc_id}} .ue_heading_title
{
  margin:0;
  flex-grow:1;
  display:flex;
  flex-direction:row;
}

#{{uc_id}} .uc_container .uc-heading
{
	display:flex;
    align-items:center;
	overflow:hidden;
	cursor:pointer;
  
}
#{{uc_id}} .uc_container .uc_content
{
    display:none;
}

#{{uc_id}} .uc_container .uc-heading span.ue_accordion_icon
{
	display:flex;
    align-items:center;
   	justify-content:center;
    flex-grow:0;
    flex-shrink:0;
}
#{{uc_id}} .uc_ac_box.uc-item-active span.uc_dactive
{
	display:none;
}
#{{uc_id}} .uc_ac_box:not(.uc-item-active) span.uc_active
{
	display:none;
}
#{{uc_id}} span.ue_accordion_icon svg
{
  height:1em;
  width:1em;
}

#{{uc_id}} .uc_container .uc_btn {

    text-align: center;
    display: inline-block;
    text-decoration: none;
    transition: ease-in-out all 0.25s;
}

#{{uc_id}} .ue-item-image img
{
  width:100%;
  display:block;
  object-fit:cover;
}